library (
    name: "smarthqHelpers",
    namespace: "craigde",
    author: "craigde",
    description: "SmartHQ helpers - shared utilities for the SmartHQ app and device drivers",
    category: "Convenience",
    documentationLink: "https://github.com/craigde/hubitat-SmartHQ"
)

import groovy.transform.Field

@Field apiUrl = "https://api.brillion.geappliances.com"

@Field doorNormallyOpen      =  0x0001
@Field doorNormallyClosed    =  0x0002

def logDebug(msg)
{
    if (logEnable || parent?.isLogEnable())
    {
        log.debug(msg)
    }
}

def setupDevDetails(details)
{
    if(!details)
    {
        return
    }

    device.setLabel(details.label)
    device.setName(details.devType)

    device.updateDataValue("mac", details.mac)
}

def push(number = 0)
{
    sendEvent(name: "pushed", value: number)
}

def decodeErdString(hexStr)
{
    return new String(hubitat.helper.HexUtils.hexStringToByteArray(hexStr))
}

def decodeErdInt(byte[] val)
{
    return hubitat.helper.HexUtils.hexStringToInt(hubitat.helper.HexUtils.byteArrayToHexString(val))
}

def encodeErdInt(val, minBytes)
{
    return hubitat.helper.HexUtils.integerToHexString(val, minBytes)
}

def decodeErdSignedByte(byte val)
{
    def intVal = decodeErdInt(val)

    // signed byte: 0..127 are positive, 128..255 are negative (two's complement)
    return (intVal < 128) ? intVal : (intVal - 256)
}

def encodeErdBool(boolean val)
{
    def intVal = (true == val) ? 1 : 0
    return encodeErdInt(intVal, 1)
}

def decodeErdBool(byte val)
{
    return (val == 0x00) ? false : true
}

def encodeErdSignedByte(val)
{
    val = (val < 0) ? (val + 256) : val
    return hubitat.helper.HexUtils.integerToHexString(val, 1)
}

def refreshAppliance()
{
    parent?.request_update(buildDevDetails()?.mac)
}

def getUserId()
{
    return parent?.getUserIdForChild()
}

def hostPath()
{
    apiUrl.split("//")?.getAt(1)
}

def buildDevDetails()
{
    def details =
        [
            userId: getUserId(),
            mac: device.getDataValue("mac"),
            host: hostPath()
        ]

    return details
}

def buildErdDetails(code, value)
{
    def details =
        [
            code: code,
            value: value
        ]

    return details
}

def buildCmdDetails(cmd, data = [])
{
    def details =
        [
            cmd: cmd,
            data: data
        ]

    return details
}

def buildWssMsg(method, path, id, body = null)
{
    def msg =
        [
            kind: "websocket#api",
            action: "api",
            host: hostPath(),
            method: method,
            path: path,
            id: id
        ]

    if(body)
    {
        msg.put("body", body)
    }

    return msg
}

def buildErdSetter(devDetails, erdDetails)
{
    if([devDetails, erdDetails].contains(null))
    {
        return
    }

    def erdCodeString = erdDetails.code?.toUpperCase()?.replace("0X", "0x")

    def body =
        [
            kind: "appliance#erdListEntry",
            userId: devDetails.userId,
            applianceId: devDetails.mac,
            erd: erdCodeString,
            value: erdDetails.value,
            ackTimeout: 10,
            delay: 0
        ]

    def path = "/v1/appliance/${devDetails.mac}/erd/${erdCodeString}"
    def id = "${devDetails.mac}-setErd-${erdCodeString}"
    def message = buildWssMsg("POST", path, id, body)

    return message
}

def buildAppCtrlSetter(devDetails, cmdDetails)
{
    if([devDetails, cmdDetails].contains(null))
    {
        return
    }

    def body =
        [
            kind: "appliance#control",
            userId: devDetails.userId,
            applianceId: devDetails.mac,
            command: cmdDetails.cmd,
            data: cmdDetails.data,
            ackTimeout: 10,
            delay: 0
        ]

    def path = "/v1/appliance/${devDetails.mac}/control/${cmdDetails.cmd}"
    def id = ""
    def message = buildWssMsg("POST", path, id, body)

    return message
}

private subBytes(arr, start, length)
{
    return arr.toList().subList(start, start + length) as byte[]
}

def flushEvents(events)
{
    events.each
    {
        // skip empty/incomplete maps so accidental [[:]] initializers don't
        // produce sendEvent calls with null name/value
        if(it?.name)
        {
            sendEvent(it)
        }
    }
}

def parseDoorStatusByte(value, type)
{
    try
    {
        def bytes = hubitat.helper.HexUtils.hexStringToByteArray(value)
        if(1 != bytes.size())
        {
            return
        }

        def val = "NA"
        def nClosed = (type == doorNormallyClosed)

        val = nClosed ? doorNCStatus(bytes[0]) : doorNOStatus(bytes[0])

        def events = []
        events += [name: "contact", value: val]
        events += [name: "doorStatus", value: val]

        flushEvents(events)
    }
    catch (Exception e)
    {
        logDebug("parseDoorStatusByte: ${e.message}")
    }
}

def doorNCStatus(val)
{
    switch(val)
    {
        case 0x01:
            return "open"
        case 0x00:
            return "closed"
        default:
            return "NA"
    }
}

def doorNOStatus(val)
{
    switch(val)
    {
        case 0x00:
            return "open"
        case 0x01:
            return "closed"
        default:
            return "NA"
    }
}

def setBooleanErd(erd, boolean value)
{
    def strVal = encodeErdBool(value)
    def erdMap = buildErdSetter(buildDevDetails(), buildErdDetails(erd, strVal))

    parent?.sendWssMap(erdMap)
}

def setSabbathMode(value)
{
    def boolVal = (value == "true")
    setBooleanErd(SABBATH_MODE, boolVal)
}

def parseSabbathMode(value)
{
    try
    {
        def bytes = hubitat.helper.HexUtils.hexStringToByteArray(value)
        def label = decodeErdBool(bytes?.getAt(0)) ? "enabled" : "disabled"
        sendEvent(name: "sabbathMode", value: label)
    }
    catch (Exception e)
    {
        logDebug("parseSabbathMode: ${e.message}")
    }
}

def setSoundLevel(value)
{
    def boolVal = (value == "true")
    setBooleanErd(SOUND_LEVEL, boolVal)
}

def setControlLock(value)
{
    def boolVal = (value == "true")
    setBooleanErd(USER_INTERFACE_LOCKED, boolVal)
}

def parseControlLock(value)
{
    try
    {
        def bytes = hubitat.helper.HexUtils.hexStringToByteArray(value)
        def label = decodeErdBool(bytes?.getAt(0)) ? "locked" : "unlocked"
        sendEvent(name: "controlPanel", value: label)
    }
    catch (Exception e)
    {
        logDebug("parseControlLock: ${e.message}")
    }
}

//
// Generic ERD helpers used by enum-style attributes (light level, fan speed,
// etc). Previously duplicated in portableAC, iceMaker, and hood drivers.
//

def parseIntegerErd(value, width, options, eventName)
{
    try
    {
        def bytes = hubitat.helper.HexUtils.hexStringToByteArray(value)
        def label = options[decodeErdInt(subBytes(bytes, 0, width))]

        def eventVal = (null != label) ? label : "unknown"
        sendEvent(name: eventName, value: eventVal)

        return eventVal
    }
    catch (Exception e)
    {
        logDebug("parseIntegerErd: ${e.message}")
        return null
    }
}

def setIntegerErd(val, options, erd)
{
    def intVal = options.find { val == it.value }?.key?.toInteger()

    if(null == intVal)
    {
        // unsupported value sent, so discarding
        logDebug("invalid setting (${val})")
        return
    }

    def erdVal = encodeErdInt(intVal, 1)
    def erdMap = buildErdSetter(buildDevDetails(), buildErdDetails(erd, erdVal))

    parent?.sendWssMap(erdMap)
}

@Field APPLIANCE_TYPE = "0x0008"
@Field CLOCK_FORMAT = "0x0006"
@Field CLOCK_TIME = "0x0005"
@Field MODEL_NUMBER = "0x0001"
@Field SABBATH_MODE = "0x0009"
@Field SERIAL_NUMBER = "0x0002"
@Field SOUND_LEVEL = "0x000a"
@Field TEMPERATURE_UNIT = "0x0007"
@Field USER_INTERFACE_LOCKED = "0x0004"
@Field UNIT_TYPE = "0x0035"